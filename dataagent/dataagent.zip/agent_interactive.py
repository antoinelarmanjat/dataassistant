import asyncio
import os
import sys
from google import adk
from google.adk.runners import InMemoryRunner
from bq_tools import scan_datasets, save_selected_datasets, load_selected_datasets, remove_selected_datasets, analyze_dataset, execute_query, save_dataset_analysis, save_query, load_saved_queries, export_query_to_gcs, export_query_to_sheets, load_dataset_analysis, set_default_dataset, load_default_dataset

# Configure for Vertex AI using ambient credentials
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
os.environ["GOOGLE_CLOUD_PROJECT"] = "antoine-279922"
os.environ["GOOGLE_CLOUD_LOCATION"] = "global"

MODEL_NAME = "gemini-3-flash-preview"

async def main():
    print(f"Initializing agent with model: {MODEL_NAME}")
    
    agent = adk.Agent(
        name="BigQueryAssistant",
        model=MODEL_NAME,
        instruction=(
            "You are a helpful assistant that helps users manage BigQuery datasets. "
            "1. At the VERY BEGINNING of the conversation, always use `load_selected_datasets` to check for saved datasets, AND use `load_default_dataset` to check if a default is configured. "
            "2. Greet the user with the list of saved datasets. If a default dataset is set, explicitly mention it as the active default. "
            "   - Ask if they want to ADD, REMOVE, or MODIFY the saved list, or **set/change the DEFAULT dataset** using `set_default_dataset`."
            "3. If they want to ADD or MODIFY, show them accessible options USING `scan_datasets`. "
            "4. Based on their input, use the appropriate tool: `save_selected_datasets` or `remove_selected_datasets`. "
            "5. If a user CONFIRMS which dataset they want to use (or selects one), ALWAYS use `load_saved_queries` to show them previous queries that were ran for it. "
            "6. If the user asks to ANALYZE a dataset, use `analyze_dataset` to gather table metadata and statistics. "
            "   - **Formulate your analysis thought, and IMMEDIATELY use `save_dataset_analysis`** to store it in background. Present the analysis text to the user. "
            "7. To fetch or view data (e.g., after analysis), use `load_dataset_analysis` to retrieve previous semantic insights for the context scope dataset BEFORE translating to SQL. "
            "   - Translate the user's request into a valid BigQuery `SELECT` statement and execute it using `execute_query` using those memory insights. "
            "   - **Show the result immediately** (it will render as a clean Markdown table). "
            "   - **Directly suggest exporting the result to Google Sheets** using `export_query_to_sheets`. "
            "   - **If the tool output contains a [WARNING] that the set is too big for chat**, suggest exporting to a GCS bucket using `export_query_to_gcs` instead. "
            "   - **Afterwards, ask the user if they want to STORE the query setup** for the future using `save_query`. "
            "8. **Continuous Learning**: When adding/saving queries, if you learned something new about table semantics or column correlations, use `save_dataset_analysis` to append those semantic notes to keep enhancing references for future scope queries."
            "   - If unsure about the SQL statement requirements, ask the user to clarify. "
            "Be conversational and guide the user."
        ),
        tools=[scan_datasets, save_selected_datasets, load_selected_datasets, remove_selected_datasets, analyze_dataset, execute_query, save_dataset_analysis, save_query, load_saved_queries, export_query_to_gcs, export_query_to_sheets, load_dataset_analysis, set_default_dataset, load_default_dataset]
    )
    
    runner = InMemoryRunner(agent=agent)
    
    print("\n--- BigQuery Assistant ---")
    print("Type 'exit' to quit.\n")
    
    # Trigger initial dataset check automatically on connect
    print("Agent is connecting and greeting you...")
    await runner.run_debug("Hello", quiet=False, verbose=True)
    print("") # Newline
    
    while True:
        try:
             # Use asyncio.to_thread for input to avoid blocking the event loop
             # or simply use standard input() since we are in a simple loop.
             user_input = input("You > ")
             if user_input.lower() in ["exit", "quit"]:
                  break
                  
             if not user_input.strip():
                  continue
                  
             print("Agent is thinking...")
             # run_debug with quiet=False streams output correctly to console
             await runner.run_debug(user_input, quiet=False, verbose=True)
             print("") # Newline after response

        except (KeyboardInterrupt, EOFError):
             print("\nExiting...")
             break
        except Exception as e:
             print(f"Error: {e}")

if __name__ == "__main__":
    # Ensure stdout is unbuffered
    sys.stdout.reconfigure(line_buffering=True)
    asyncio.run(main())
