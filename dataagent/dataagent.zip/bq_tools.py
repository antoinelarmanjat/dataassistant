import os
import time
from google.cloud import bigquery

def scan_datasets(limit: int = 10) -> str:
    """
    Scans and lists BigQuery datasets the user has access to, limited to top projects.

    Args:
        limit: Max number of projects to scan. Defaults to 10.

    Returns:
        A formatted string listing projects and their datasets.
    """
    try:
        client = bigquery.Client()
        output = []
        current_project = client.project
        projects = [current_project]
        
        # Add other projects from iterator until limit is reached
        for p in client.list_projects(max_results=limit):
            if p.project_id != current_project:
                projects.append(p.project_id)
            if len(projects) >= limit:
                break
                
        if not projects:
            return "No projects found."
            
        for project_id in projects:
            output.append(f"Project: {project_id}")
            with open("/tmp/bq_scan.log", "a") as f:
                 f.write(f"Scanning project: {project_id}\n")
            try:
                datasets = list(client.list_datasets(project=project_id, max_results=limit))
                if datasets:
                    for d in datasets:
                        output.append(f"  - Dataset: {d.dataset_id}")
                else:
                    output.append("  - No datasets found.")
            except Exception as e:
                output.append(f"  - Error listing datasets: {e}")
                
        return "\n".join(output)
    except Exception as e:
        return f"Error scanning datasets: {e}"

def save_selected_datasets(selected_datasets: list[str], dataset_name: str = "user_workspace") -> str:
    """
    Creates a dataset is the current GCP project to store the list of datasets the user wants to work on.

    Args:
        selected_datasets: A list of dataset names (e.g., ["project_id.dataset_id", ...]) or just dataset IDs.
        dataset_name: The name of the dataset to create to store the list. Defaults to 'user_workspace'.

    Returns:
        A success or failure message.
    """
    try:
        client = bigquery.Client()
        project_id = client.project
        
        # 1. Create the dataset if not exists
        dataset_id = f"{project_id}.{dataset_name}"
        dataset = bigquery.Dataset(dataset_id)
        dataset.description = "Stores user selected workspaces"
        
        try:
            client.get_dataset(dataset_id)
            output_msg = f"Dataset '{dataset_name}' already exists.\n"
        except Exception:
            # Not found, create it
            client.create_dataset(dataset)
            output_msg = f"Created dataset '{dataset_name}'.\n"
            
        # 2. Create the table to store the list
        table_id = f"{dataset_id}.selected_datasets"
        schema = [
            bigquery.SchemaField("dataset_name", "STRING", mode="REQUIRED")
        ]
        table = bigquery.Table(table_id, schema=schema)
        
        try:
            client.get_table(table_id)
            output_msg += "Table 'selected_datasets' already exists.\n"
        except Exception:
            client.create_table(table)
            output_msg += "Created table 'selected_datasets'.\n"
            
        # 3. Insert the selected datasets
        rows_to_insert = [{"dataset_name": d} for d in selected_datasets]
        errors = client.insert_rows_json(table_id, rows_to_insert)
        
        if not errors:
            output_msg += f"Successfully saved {len(selected_datasets)} selections."
        else:
            output_msg += f"Errors inserting rows: {errors}"
            
        return output_msg
        
    except Exception as e:
        return f"Error saving selected datasets: {e}"

def load_selected_datasets(dataset_name: str = "user_workspace") -> list[str]:
    """
    Loads the list of previously selected datasets from the workspace storage.

    Args:
        dataset_name: The dataset name. Defaults to 'user_workspace'.

    Returns:
        A list of string dataset names, or an empty list if none found.
    """
    try:
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{dataset_name}.selected_datasets"
        
        try:
            rows = client.list_rows(table_id)
            return [row["dataset_name"] for row in rows]
        except Exception:
            # Table or dataset doesn't exist yet
            return []
    except Exception:
        return []

def remove_selected_datasets(datasets_to_remove: list[str], dataset_name: str = "user_workspace") -> str:
    """
    Removes the specified datasets from the workspace storage list.

    Args:
        datasets_to_remove: A list of dataset names to remove (e.g., ["project_id.dataset_id", ...]).
        dataset_name: The dataset name. Defaults to 'user_workspace'.

    Returns:
        A success or failure message.
    """
    try:
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{dataset_name}.selected_datasets"
        
        if not datasets_to_remove:
            return "No datasets provided to remove."
            
        datasets_str = ", ".join([f"'{d}'" for d in datasets_to_remove])
        query = f"DELETE FROM `{table_id}` WHERE dataset_name IN ({datasets_str})"
        
        query_job = client.query(query)
        query_job.result()
        
        return f"Successfully removed {len(datasets_to_remove)} datasets from selection."
    except Exception as e:
        return f"Error removing selected datasets: {e}"

def analyze_dataset(dataset_name: str) -> str:
    """
    Gathers statistics and metadata for a specific BigQuery dataset and its tables.
    
    Args:
        dataset_name: The dataset ID or full 'project.dataset'.
        
    Returns:
        Structured text describing table rows, sizes, and schema columns.
    """
    try:
        client = bigquery.Client()
        if "." in dataset_name:
             project_id, dataset_id = dataset_name.split(".", 1)
        else:
             project_id = client.project
             dataset_id = dataset_name
             
        dataset_ref = client.dataset(dataset_id, project=project_id)
        tables = client.list_tables(dataset_ref)
        
        output = [f"Analysis of Dataset: {project_id}.{dataset_id}\n"]
        
        has_tables = False
        for table in tables:
             has_tables = True
             t = client.get_table(table.reference)
             output.append(f"Table: {t.table_id}")
             output.append(f"  - Rows: {t.num_rows}")
             output.append(f"  - Size: {t.num_bytes} bytes")
             output.append(f"  - Schema:")
             for field in t.schema:
                  output.append(f"    * {field.name} ({field.field_type}) - {field.description or 'No description'}")
             output.append("")
             
        if not has_tables:
             return f"No tables found in dataset '{project_id}.{dataset_id}'."
             
        return "\n".join(output)
    except Exception as e:
        return f"Error analyzing dataset '{dataset_name}': {e}"

def execute_query(sql: str) -> str:
    """
    Executes a SQL query on BigQuery and returns the results.
    
    Args:
        sql: The SQL query string to execute.
        
    Returns:
        Structured text describing the query results (rows).
    """
    try:
        client = bigquery.Client()
        query_job = client.query(sql)
        results = query_job.result()
        
        output = [f"Query executed successfully. Rows found: {results.total_rows}\n"]
        if results.total_rows > 10:
             output.append("[WARNING] Result set is large. Showing only the first 10 rows in chat.")
             output.append("[SUGGESTION] You can export full results using `export_query_to_gcs` or `export_query_to_sheets`.\n")
             
        # Format as Markdown Table
        if not hasattr(results, 'schema'):
             return "Query executed successfully, but returned no structured schema."
             
        headers = [f.name for f in results.schema]
        output.append("| " + " | ".join(headers) + " |")
        output.append("| " + " | ".join(["---"] * len(headers)) + " |")
        
        counter = 0
        for row in results:
             counter += 1
             values = [str(row[f.name]) for f in results.schema]
             output.append("| " + " | ".join(values) + " |")
             if counter >= 10:
                  output.append("\n... [Output truncated after 10 rows for display]")
                  break
                  
        if results.total_rows == 0:
             return "Query executed successfully. No rows returned."
             
        return "\n".join(output)
    except Exception as e:
        return f"Error executing query: {e}"

def save_dataset_analysis(dataset_name: str, analysis: str, workspace_dataset: str = "user_workspace") -> str:
    """
    Stores an analysis summary for a given dataset in the workspace.
    
    Args:
        dataset_name: The dataset ID or full 'project.dataset' being analyzed.
        analysis: The text analysis formulated by the assistant.
        workspace_dataset: Destination workspace holding selection lists.
        
    Returns:
        Success or error string.
    """
    try:
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{workspace_dataset}.dataset_analysis"
        
        # 1. Ensure Table Exists
        schema = [
             bigquery.SchemaField("dataset_name", "STRING", mode="REQUIRED"),
             bigquery.SchemaField("analysis", "STRING", mode="REQUIRED")
        ]
        table = bigquery.Table(table_id, schema=schema)
        try:
             client.get_table(table_id)
        except Exception:
             client.create_table(table)
             
        # 2. Insert row (Upsert is cleaner but insert is faster. Let's append!)
        rows_to_insert = [{"dataset_name": dataset_name, "analysis": analysis}]
        errors = client.insert_rows_json(table_id, rows_to_insert)
        if errors:
             return f"Error saving analysis: {errors}"
        return f"Successfully saved analysis for '{dataset_name}'."
    except Exception as e:
        return f"Error storing analysis: {e}"

def save_query(query_name: str, sql: str, description: str, dataset_name: str, workspace_dataset: str = "user_workspace") -> str:
    """
    Saves a custom SQL query referenced by the user to the workspace.
    
    Args:
        query_name: Custom mnemonic/title for the query.
        sql: The valid SELECT SQL string.
        description: Brief description about what the query fetches.
        dataset_name: Active scope context item.
    """
    try:
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{workspace_dataset}.saved_queries"
        
        import re
        # Clean query name for valid BQ view ID
        cleaned_name = re.sub(r'[^a-zA-Z0-9_]', '_', query_name).lower()
        view_name = f"view_{cleaned_name}"
        view_id = f"{project_id}.{workspace_dataset}.{view_name}"
        
        # 1. Create or Replace View
        try:
             client.query(f"CREATE OR REPLACE VIEW `{view_id}` AS {sql}").result()
        except Exception as e:
             return f"Error creating view {view_name}: {e}"
             
        # 2. Add column to schema if strictly necessary
        schema = [
             bigquery.SchemaField("dataset_name", "STRING", mode="REQUIRED"),
             bigquery.SchemaField("query_name", "STRING", mode="REQUIRED"),
             bigquery.SchemaField("sql", "STRING", mode="REQUIRED"),
             bigquery.SchemaField("description", "STRING", mode="REQUIRED"),
             bigquery.SchemaField("view_name", "STRING")
        ]
        table = bigquery.Table(table_id, schema=schema)
        try:
             existing_table = client.get_table(table_id)
             has_view_name = any(f.name == "view_name" for f in existing_table.schema)
             if not has_view_name:
                  new_schema = existing_table.schema[:]
                  new_schema.append(bigquery.SchemaField("view_name", "STRING"))
                  existing_table.schema = new_schema
                  client.update_table(existing_table, ["schema"])
        except Exception:
             client.create_table(table)
             
        # 3. Clear previous metadata row to prevent duplicates (Upsert)
        try:
             delete_sql = f"DELETE FROM `{table_id}` WHERE dataset_name = '{dataset_name}' AND query_name = '{query_name}'"
             client.query(delete_sql).result()
        except Exception:
             pass
             
        rows_to_insert = [{
             "dataset_name": dataset_name,
             "query_name": query_name,
             "sql": sql,
             "description": description,
             "view_name": view_name
        }]
        errors = client.insert_rows_json(table_id, rows_to_insert)
        if errors:
             return f"Error saving query metadata: {errors}"
        return f"Successfully saved query and created view '{view_name}'."
    except Exception as e:
        return f"Error saving query: {e}"

def load_saved_queries(dataset_name: str, workspace_dataset: str = "user_workspace") -> str:
    """
    Loads custom queries that were previously saved for a given dataset scope.
    """
    try:
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{workspace_dataset}.saved_queries"
        
        # Check schema first to see if view_name column exists
        existing_table = client.get_table(table_id)
        columns = [f.name for f in existing_table.schema]
        select_cols = "query_name, sql, description"
        if "view_name" in columns:
             select_cols += ", view_name"
             
        query = f"SELECT {select_cols} FROM `{table_id}` WHERE dataset_name = '{dataset_name}'"
        query_job = client.query(query)
        results = query_job.result()
        
        output = [f"Saved Queries for {dataset_name}:\n"]
        has_items = False
        for row in results:
             has_items = True
             view_info = f" (View: {row.view_name})" if "view_name" in columns and row.view_name else ""
             output.append(f"* **{row.query_name}**{view_info}: {row.description}")
             output.append(f"  `{row.sql}`\n")
             
        if not has_items:
             return f"No saved queries found for dataset '{dataset_name}'."
        return "\n".join(output)
    except Exception as e:
        return f"No saved queries found (Table might not exist yet)."

def export_query_to_sheets(sql: str, spreadsheet_title: str) -> str:
    """
    Executes a query and creates a new Google Spreadsheet containing the results.
    Creates a spreadsheet and updates values using the v4 Sheets API set.
    """
    try:
        from googleapiclient.discovery import build
        from google.cloud import bigquery
        
        # 1. Run Query
        client_bq = bigquery.Client()
        query_job = client_bq.query(sql)
        results = query_job.result()
        
        # 2. Format Rows
        if not hasattr(results, 'schema'):
             return "Query returned no schema layout to export."
             
        headers = [f.name for f in results.schema]
        rows = [headers]
        for row in results:
             rows.append([str(row[f.name]) for f in results.schema])
             
        if len(rows) <= 1:
             return "Query returned no rows to export."
             
        # 3. Create Spreadsheet
        service = build('sheets', 'v4')
        spreadsheet_body = {
             'properties': {
                  'title': spreadsheet_title
             }
        }
        res = service.spreadsheets().create(body=spreadsheet_body).execute()
        spreadsheet_id = res.get('spreadsheetId')
        spreadsheet_url = res.get('spreadsheetUrl')
        
        # 4. Append Values
        value_range_body = {
             'values': rows
        }
        service.spreadsheets().values().update(
             spreadsheetId=spreadsheet_id,
             range="Sheet1!A1",
             valueInputOption="USER_ENTERED",
             body=value_range_body
        ).execute()
        
        return f"Successfully created Spreadsheet '{spreadsheet_title}'. URL: {spreadsheet_url}"
    except Exception as e:
        return f"Error exporting to Sheets: {e}"

def export_query_to_gcs(sql: str, bucket_name: str, file_name: str = "result.csv", workspace_dataset: str = "user_workspace") -> str:
    """
    Executes a query and exports the full results to a Google Cloud Storage bucket.
    Creates the bucket if it does not exist.
    """
    try:
        from google.cloud import storage
        client_bq = bigquery.Client()
        client_gcs = storage.Client()
        
        project_id = client_bq.project
        
        # 1. Create Bucket if not exists
        try:
             bucket = client_gcs.get_bucket(bucket_name)
        except Exception:
             bucket = client_gcs.create_bucket(bucket_name)
             
        # 2. Save Query to Temp Table
        temp_table_id = f"{project_id}.{workspace_dataset}.temp_export_{int(time.time())}"
        
        job_config = bigquery.QueryJobConfig(
             destination=temp_table_id,
             write_disposition="WRITE_TRUNCATE"
        )
        query_job = client_bq.query(sql, job_config=job_config)
        query_job.result() # Wait for query
        
        # 3. Extract to GCS
        destination_uri = f"gs://{bucket_name}/{file_name}"
        extract_job = client_bq.extract_table(temp_table_id, destination_uri)
        extract_job.result() # Wait for extract
        
        # 4. Clean up temp table
        client_bq.delete_table(temp_table_id)
        
        return f"Successfully exported full query results to {destination_uri}"
        
    except Exception as e:
        return f"Error exporting to GCS: {e}"

def load_dataset_analysis(dataset_name: str, workspace_dataset: str = "user_workspace") -> str:
    """
    Loads saved semantic analysis and insights for a given dataset scope.
    """
    try:
        from google.cloud import bigquery
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{workspace_dataset}.dataset_analysis"
        
        query = f"SELECT analysis FROM `{table_id}` WHERE dataset_name = '{dataset_name}'"
        query_job = client.query(query)
        results = query_job.result()
        
        output = [f"Accumulated Insights for {dataset_name}:\n"]
        has_items = False
        for row in results:
             has_items = True
             output.append(f"- {row.analysis}")
             
        if not has_items:
             return f"No previous analysis found for dataset '{dataset_name}'."
        return "\n".join(output)
    except Exception as e:
        return f"No previous analysis found (Table might not exist yet)."

def set_default_dataset(dataset_name: str, workspace_dataset: str = "user_workspace") -> str:
    """
    Sets a specific dataset as the default dataset for the workspace.
    """
    try:
        from google.cloud import bigquery
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{workspace_dataset}.default_dataset"
        
        schema = [bigquery.SchemaField("dataset_name", "STRING", mode="REQUIRED")]
        table = bigquery.Table(table_id, schema=schema)
        
        try:
             client.get_table(table_id)
        except Exception:
             client.create_table(table)
             
        # 1. Clear previous default
        client.query(f"DELETE FROM `{table_id}` WHERE true").result()
        
        # 2. Insert new default
        rows = [{"dataset_name": dataset_name}]
        errors = client.insert_rows_json(table_id, rows)
        if errors:
             return f"Error setting default: {errors}"
        return f"Successfully set '{dataset_name}' as your default dataset."
    except Exception as e:
        return f"Error setting default dataset: {e}"

def load_default_dataset(workspace_dataset: str = "user_workspace") -> str:
    """
    Loads the default dataset if one is set. Returns the string name or 'None'.
    """
    try:
        from google.cloud import bigquery
        client = bigquery.Client()
        project_id = client.project
        table_id = f"{project_id}.{workspace_dataset}.default_dataset"
        
        query = f"SELECT dataset_name FROM `{table_id}` LIMIT 1"
        query_job = client.query(query)
        results = query_job.result()
        
        for row in results:
             return row.dataset_name
        return "None"
    except Exception:
        return "None"
